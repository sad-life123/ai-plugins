<?php
// /ai/placement/textprocessor/version.php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'aiplacement_textprocessor';
$plugin->version = 2026021301;
$plugin->requires = 2024100700; // Moodle 4.5+
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '2.0.0';
// БЕЗ ЗАВИСИМОСТЕЙ!