<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

use core_ai\admin\admin_settingspage_provider;

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // Create settings page for the plugin.
    $settings = new admin_settingspage_provider(
        'aiplacement_textprocessor',
        get_string('pluginname', 'aiplacement_textprocessor'),
        'moodle/site:config',
        true, // This is an AI placement.
    );

    // ============================================
    // 🦙 OLLAMA SETTINGS (Fallback)
    // ============================================
    $settings->add(new admin_setting_heading('ollama_heading',
        '🦙 Ollama Settings (Fallback)',
        'These settings are used if Ollama provider is not configured'
    ));

    $settings->add(new admin_setting_configtext(
        'aiplacement_textprocessor/ollama_url',
        'Ollama Server URL',
        'Ollama API address (default: http://localhost:11434)',
        'http://localhost:11434',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configtext(
        'aiplacement_textprocessor/ollama_model',
        'Text Processing Model',
        'Recommended: llama3.1, qwen2.5, mistral',
        'qwen2:1.5b',
        PARAM_TEXT
    ));

    // Add the settings page to the AI section.
    $ADMIN->add('ai', $settings);
}
