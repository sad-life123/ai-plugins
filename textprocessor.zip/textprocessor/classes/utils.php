<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace aiplacement_textprocessor;

use core_ai\manager;

/**
 * AI Placement TextProcessor utils.
 *
 * @package    aiplacement_textprocessor
 * @copyright  2025
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class utils {

    /**
     * Check if AI Placement TextProcessor action is available for the context.
     *
     * @param \context $context The context.
     * @param string $actionname The name of the action.
     * @param string $actionclass The class name of the action.
     * @return bool True if the action is available, false otherwise.
     */
    public static function is_textprocessor_placement_action_available(
        \context $context,
        string $actionname,
        string $actionclass
    ): bool {
        [$plugintype, $pluginname] = explode('_', \core_component::normalize_componentname('aiplacement_textprocessor'), 2);
        $pluginmanager = \core_plugin_manager::resolve_plugininfo_class($plugintype);
        if (!$pluginmanager::is_plugin_enabled($pluginname)) {
            return false;
        }

        $aimanager = \core\di::get(manager::class);
        if (
            has_capability("aiplacement/textprocessor:{$actionname}", $context)
            && $aimanager->is_action_available($actionclass)
            && $aimanager->is_action_enabled('aiplacement_textprocessor', $actionclass)
        ) {
            return true;
        }
        return false;
    }
}
