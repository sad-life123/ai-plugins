<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

defined('MOODLE_INTERNAL') || die();

/**
 * Add "Generate Quiz" button to editor.
 */
function aiplacement_quizgen_tiny_plugin_definitions() {
    return [
        'aiplacement_quizgen' => [
            'title' => 'AI Quiz Generator',
            'icon' => 'quiz',
            'buttons' => [
                'generate_quiz' => [
                    'text' => '📝 AI Quiz',
                    'action' => 'openQuizGenerator'
                ]
            ]
        ]
    ];
}

/**
 * Add item to course menu.
 */
function aiplacement_quizgen_extend_navigation_course($navigation, $course, $context) {
    global $PAGE;

    if (has_capability('aiplacement/quizgen:generate', $context)) {
        $url = new moodle_url('/ai/placement/quizgen/index.php', ['courseid' => $course->id]);
        $navigation->add(
            '📝 AI Quiz Generator',
            $url,
            navigation_node::TYPE_SETTING,
            null,
            'quizgen',
            new pix_icon('i/questions', '')
        );
    }
}

/**
 * Handle before course deletion.
 */
function aiplacement_quizgen_pre_course_delete($course) {
    // Clean up generated questions.
    $category = question_get_default_category($course->id);
    if ($category) {
        $questions = get_questions_in_category($category->id);
        foreach ($questions as $question) {
            if (strpos($question->name, '[AI]') === 0) {
                question_delete_question($question->id);
            }
        }
    }
}
